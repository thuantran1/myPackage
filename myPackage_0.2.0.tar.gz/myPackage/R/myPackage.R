#' Custom Package
#'
#' Contains various functions from previous labs for newer labs where using this package is necesssary.
#'
#' @docType package
#'
#' @author Thuan Tran
#'
#' @name myPackage
NULL
