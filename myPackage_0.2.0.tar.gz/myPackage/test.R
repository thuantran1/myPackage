library(myPackage)
library(ggplot2)
library(dplyr)


download.packages(pkgs = "myPackage", destdir = "C:/Users/meatl/OneDrive/Desktop/Stats/Project 1")
